# -*- coding: utf-8 -*-
# Em: resources/lib/tvshows.py

import os
import re
import json
import requests
import sys
import xbmcaddon
import xbmcgui
import xbmcplugin
from urllib.parse import urlencode

# Importações do seu projeto
from .db import db
from .utils import create_video_item, with_view_mode
from .navigation import _fetch_json_from_url
from .tmdb_api import fetch_show_details # Usada por list_seasons

# Configurações e funções comuns
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
DEFAULT_ITEMS_PER_PAGE = int(ADDON.getSetting("pages"))
TMDB_API_KEY = "f0b9cd2de131c900f5bb03a0a5776342"

ADDON_PATH = ADDON.getAddonInfo('path')
ICON_PATH = os.path.join(ADDON_PATH, 'resources', 'medias', 'icons')


def get_url(**kwargs):
    """Cria uma URL de plugin para uma ação."""
    return f"{BASE_URL}?{urlencode(kwargs)}"


# --- ✅ NOVAS FUNÇÕES AUXILIARES ---

def _prepare_details_data(item_data):
    """Prepara um dicionário com os dados do item para a URL da tela de detalhes."""
    genre_str = ', '.join(item_data.get('genres', []))  # Lista → string
    providers_list = item_data.get('providers', [])
    return {
        'tmdb_id': item_data.get('tmdb_id'),
        'imdb_id': item_data.get('imdb_id'),
        'title': item_data.get('title'),
        'original_title': item_data.get('original_title', item_data.get('title')),  # ✅ adicione aqui
        'clearlogo': item_data.get('clearlogo'),
        'synopsis': item_data.get('synopsis'),
        'poster': item_data.get('poster'),
        'backdrop': item_data.get('backdrop'),
        'year': item_data.get('year'),
        'rating': item_data.get('rating'),
        'certification': item_data.get('certification'),
        'trailer': item_data.get('trailer'),
        'genre': genre_str,
        'media_type': 'tvshow',
        'providers': json.dumps(providers_list)
    }


def _add_show_item_to_list(show_data):
    """Cria o ListItem para uma série e o adiciona ao diretório do Kodi."""
    li = create_video_item(show_data, 'tvshow')

    if ADDON.getSettingBool('enable_details_dialog'):
        details_data = _prepare_details_data(show_data)
        url = get_url(action='show_details', data=json.dumps(details_data, ensure_ascii=False))
        is_folder = False
    else:
        url = get_url(action='list_seasons', tvshow_tmdb_id=show_data.get('tmdb_id'))
        is_folder = True

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# --- FUNÇÕES DE NAVEGAÇÃO DE SÉRIES ---

@with_view_mode('files', is_menu=True)
def show_tvshows_menu(menu_structure):
    """Cria e exibe o menu da seção 'Séries'."""
    xbmcplugin.setPluginCategory(HANDLE, 'Séries')
    xbmcplugin.setContent(HANDLE, 'files')
    for item in menu_structure:
        li = xbmcgui.ListItem(label=item['title'])
        icon = item.get('icon')
        if icon:
            li.setArt({'thumb': icon})
        url = get_url(action=item['action'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def add_next_page_item(items_on_current_page, current_page, **kwargs):
    """Adiciona o item 'Próxima Página' a uma lista se houver mais itens."""
    if len(items_on_current_page) == DEFAULT_ITEMS_PER_PAGE:
        next_icon = os.path.join(ICON_PATH, 'nextpage.png')
        li_next = xbmcgui.ListItem(label="Próxima Página")
        li_next.setArt({'thumb': next_icon, 'icon': next_icon})
        li_next.setInfo('video', {'plot': f'Ir para a página {current_page + 1}'})

        next_page_args = kwargs.copy()
        next_page_args['page'] = current_page + 1
        next_page_url = get_url(**next_page_args)

        xbmcplugin.addDirectoryItem(HANDLE, next_page_url, li_next, isFolder=True)

def list_seasons(tvshow_tmdb_id):
    """
    Lista temporadas, AGORA COM CACHE.
    """
    
    # 1. Busca dados da SÉRIE no DB local (como antes)
    show = db.get_tvshow_by_id(tvshow_tmdb_id)
    if not show:
        return
        
    xbmcplugin.setPluginCategory(HANDLE, show['title'])
    xbmcplugin.setContent(HANDLE, 'seasons')

    # --- LÓGICA DE CACHE ---
    # 2. Tenta buscar temporadas do cache
    #    (use um setting para definir o tempo de cache, ex: 72 horas)
    try:
        cache_hours = int(ADDON.getSetting("cache_age_hours"))
    except:
        cache_hours = 12 # Padrão de 3 dias
        
    seasons_data_list = db.get_cached_seasons(tvshow_tmdb_id, cache_hours)
    
    # 3. Se o cache falhar (miss), busca na API
    if not seasons_data_list:
        show_details_tmdb = fetch_show_details(tvshow_tmdb_id)
        if not show_details_tmdb:
            return
            
        seasons_data_list = show_details_tmdb.get('seasons_data', [])
        
        # 4. SALVA O RESULTADO NO CACHE
        if seasons_data_list:
            db.save_seasons_cache(tvshow_tmdb_id, seasons_data_list)
    # --- FIM DA LÓGICA DE CACHE ---

    try:
        show_specials_enabled = ADDON.getSettingBool('show_specials')
    except:
        show_specials_enabled = False
        
    # 5. Itera sobre a lista (seja do cache ou da API)
    for season_data in seasons_data_list:
        
        # Se os dados vieram do cache, season_data é um dict
        # Se vieram da API, também é um dict. 
        # A estrutura que salvei no cache é parecida com a da API.
        
        season_number = season_data.get('season_number', season_data.get('number', 0))
        
        if season_number == 0 and not show_specials_enabled:
            continue
            
        tmdb_season_name = season_data.get('name', f"Temporada {season_number}")
        
        # Prepara dados para create_video_item
        # (O cache já salva o poster com a URL completa, se veio do cache)
        if 'poster' not in season_data and season_data.get('poster_path'):
             season_data['poster'] = f"https://image.tmdb.org/t/p/w500{season_data['poster_path']}"
        
        season_data['title'] = tmdb_season_name
        season_data['label'] = tmdb_season_name
        
        li = create_video_item(season_data, 'season', show_data=show)
        
        li.setInfo('video', {
            'title': tmdb_season_name,
            'plot': season_data.get('overview', 'Sinopse não disponível.'),
            'rating': season_data.get('vote_average', 0.0),
            'season': season_number,
            'mediatype': 'season'
        })
        
        url = get_url(
            action='list_episodes', 
            tvshow_tmdb_id=tvshow_tmdb_id, 
            season_number=season_number
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_episodes(tvshow_tmdb_id, season_number):
    """
    Lista episódios, AGORA COM CACHE.
    """
    # 1. Obter dados da SÉRIE (como antes)
    show_data = db.get_tvshow_by_id(tvshow_tmdb_id)
    if not show_data or not show_data.get('imdb_id'):
        # ... (seu tratamento de erro)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"{show_data.get('title')} - Temporada {season_number}")
    xbmcplugin.setContent(HANDLE, 'episodes')

    # --- LÓGICA DE CACHE ---
    # 2. Tenta buscar episódios do cache
    try:
        cache_hours = int(ADDON.getSetting("cache_age_hours"))
    except:
        cache_hours = 72
        
    tmdb_episodes = db.get_cached_episodes(tvshow_tmdb_id, season_number, cache_hours)
    
    # 3. Se o cache falhar (miss), busca na API
    if not tmdb_episodes:
        tmdb_episodes = _fetch_tmdb_season_details(tvshow_tmdb_id, season_number)
        
        # 4. SALVA O RESULTADO NO CACHE
        if tmdb_episodes:
            db.save_episodes_cache(tvshow_tmdb_id, season_number, tmdb_episodes)
    # --- FIM DA LÓGICA DE CACHE ---

    if not tmdb_episodes:
        xbmcgui.Dialog().ok("Aviso", "Nenhum episódio encontrado.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 5. Loop para criar os itens (do cache ou da API)
    for ep_data_tmdb in tmdb_episodes:
        
        ep_number = ep_data_tmdb.get('episode_number')
        ep_title = f"{ep_number}. {ep_data_tmdb.get('name')}"
        
        # Constrói a URL do poster do episódio (still_path)
        # O cache só salva o path, não a URL completa
        episode_poster_url = show_data.get('backdrop') # Fallback
        if ep_data_tmdb.get('still_path'):
            episode_poster_url = f"https://image.tmdb.org/t/p/w500{ep_data_tmdb.get('still_path')}"

        item_data_for_scraper = {
            'media_type': 'tvshow', 
            'imdb_id': show_data.get('imdb_id'),
            'tmdb_id': tvshow_tmdb_id,
            'title': show_data.get('title'),
            'original_title': show_data.get('original_title', show_data.get('title')),
            'year': show_data.get('year'),
            'backdrop': show_data.get('backdrop'),
            'poster': show_data.get('poster'),

            # Info específica do episódio (do cache ou API)
            'episode_title': ep_data_tmdb.get('name'),
            'plot': ep_data_tmdb.get('overview'),
            'episode_poster': episode_poster_url,
            'rating': ep_data_tmdb.get('vote_average'),
            'season': season_number,
            'episode': ep_number,
            'premiered': ep_data_tmdb.get('air_date'),
            'runtime': ep_data_tmdb.get('runtime', 0)
        }
        
        li = xbmcgui.ListItem(label=ep_title)
        
        info = {
            'title': ep_title,
            'plot': item_data_for_scraper['plot'],
            'season': item_data_for_scraper['season'],
            'episode': item_data_for_scraper['episode'],
            'rating': item_data_for_scraper['rating'],
            'aired': item_data_for_scraper['premiered'],
            'duration': (item_data_for_scraper.get('runtime') or 0) * 60,
            'tvshowtitle': item_data_for_scraper['title'],
            'mediatype': 'episode'
        }
        li.setInfo('video', info)
        
        art = {
            'thumb': item_data_for_scraper['episode_poster'],
            'fanart': item_data_for_scraper['backdrop'],
            'poster': item_data_for_scraper['poster'],
            'tvshow.poster': show_data.get('poster'),
            'tvshow.fanart': show_data.get('backdrop'),
            'tvshow.clearlogo': show_data.get('clearlogo')
        }
        li.setArt(art)
        li.setProperty('IsPlayable', 'true')

        url = get_url(
            action='find_and_play_episode', 
            item_data=json.dumps(item_data_for_scraper)
        )
        
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def _fetch_tmdb_season_details(tmdb_id, season_number):
    """Busca os detalhes de uma temporada direto do TMDB."""
    # (Manter inalterada: Esta função busca a lista de episódios do TMDB, o que é o objetivo)
    if not TMDB_API_KEY or TMDB_API_KEY == "SUA_CHAVE_API_V3_DO_TMDB_AQUI":
        xbmc.log("[ERRO] Chave de API do TMDB não configurada.", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Erro de Configuração", "A chave de API do TMDB não foi definida no arquivo 'tvshows.py'.")
        return []
        
    url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season_number}?api_key={TMDB_API_KEY}&language=pt-BR"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        return data.get('episodes', [])
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[ERRO TMDB] Falha ao buscar temporada {tmdb_id} S{season_number}: {e}", xbmc.LOGERROR)
        return []



# --- LISTAGENS DE SÉRIES (MENUS) ---

@with_view_mode('genres', is_menu=True)
def list_tvshows_genres():
    """Cria e exibe a lista de Gêneros de Séries."""
    xbmcplugin.setPluginCategory(HANDLE, 'Gêneros de Séries')
    xbmcplugin.setContent(HANDLE, 'genres')
    genres_from_db = db.get_all_unique_tvshow_genres()
    for genre_name in genres_from_db:
        li = xbmcgui.ListItem(label=genre_name)
        url = get_url(action='list_tvshows_by_genre', genre=genre_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


@with_view_mode('files', is_menu=True)
def list_providers():
    xbmcplugin.setPluginCategory(HANDLE, "Provedores")
    xbmcplugin.setContent(HANDLE, 'files')
    providers = db.get_all_unique_providers()
    for provider_name in providers:
        li = xbmcgui.ListItem(label=provider_name)
        url = get_url(action='list_tvshows_by_provider', provider=provider_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


# --- LISTAGENS DE CONTEÚDO (SÉRIES) ---

@with_view_mode('tvshows')
def list_tvshows_by_genre(genre, page=1):
    xbmcplugin.setPluginCategory(HANDLE, genre)
    xbmcplugin.setContent(HANDLE, 'tvshows')
    shows = db.get_tvshows_by_genre(genre, page, DEFAULT_ITEMS_PER_PAGE)
    for show in shows:
        _add_show_item_to_list(show)
    add_next_page_item(shows, page, action='list_tvshows_by_genre', genre=genre)
    xbmcplugin.endOfDirectory(HANDLE)


@with_view_mode('tvshows')
def list_tvshows_by_provider(provider, page=1):
    xbmcplugin.setPluginCategory(HANDLE, provider)
    xbmcplugin.setContent(HANDLE, 'tvshows')
    shows = db.get_tvshows_by_provider(provider, page, DEFAULT_ITEMS_PER_PAGE)
    for show in shows:
        _add_show_item_to_list(show)
    add_next_page_item(shows, page, action='list_tvshows_by_provider', provider=provider)
    xbmcplugin.endOfDirectory(HANDLE)


@with_view_mode('tvshows')
def list_tvshows_by_popularity(page=1):
    xbmcplugin.setPluginCategory(HANDLE, "Mais Populares")
    xbmcplugin.setContent(HANDLE, 'tvshows')
    shows = db.get_tvshows_by_popularity(page, DEFAULT_ITEMS_PER_PAGE)
    for show in shows:
        _add_show_item_to_list(show)
    add_next_page_item(shows, page, action='list_tvshows_by_popularity')
    xbmcplugin.endOfDirectory(HANDLE)


@with_view_mode('tvshows')
def list_animes(page=1):
    xbmcplugin.setPluginCategory(HANDLE, "Animes")
    xbmcplugin.setContent(HANDLE, 'tvshows')
    shows = db.get_tvshows_by_genre('anime', page, DEFAULT_ITEMS_PER_PAGE)
    for show in shows:
        _add_show_item_to_list(show)
    add_next_page_item(shows, page, action='list_animes')
    xbmcplugin.endOfDirectory(HANDLE)


@with_view_mode('tvshows')
def list_kids_tvshows(page=1):
    xbmcplugin.setPluginCategory(HANDLE, "Infantil")
    xbmcplugin.setContent(HANDLE, 'tvshows')
    shows = db.get_kids_tvshows(page, DEFAULT_ITEMS_PER_PAGE)
    for show in shows:
        _add_show_item_to_list(show)
    add_next_page_item(shows, page, action='list_kids_tvshows')
    xbmcplugin.endOfDirectory(HANDLE)


@with_view_mode('tvshows')
def list_recently_added_tvshows(page=1):
    xbmcplugin.setPluginCategory(HANDLE, "Adicionados Recentemente")
    xbmcplugin.setContent(HANDLE, 'tvshows')
    shows = db.get_recently_added_tvshows(page, DEFAULT_ITEMS_PER_PAGE)
    for show in shows:
        _add_show_item_to_list(show)
    add_next_page_item(shows, page, action='list_recently_added_tvshows')
    xbmcplugin.endOfDirectory(HANDLE)
